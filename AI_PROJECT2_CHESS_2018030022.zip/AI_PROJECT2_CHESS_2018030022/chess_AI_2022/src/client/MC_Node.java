package client;

import java.util.ArrayList;

public class MC_Node implements Comparable<MC_Node> {
    public MC_Node parent;
    public ArrayList<MC_Node> children;
    public int totalScore;
    public String move;
    public String[][] state;
    public boolean myTurn;
    public boolean terminalState;
    public int timesVisited;

    public MC_Node(String move, String[][] state, MC_Node parent, boolean myTurn, boolean terminalState) {
        this.move = move;
        children = new ArrayList<>();
        this.timesVisited = 0;
        this.myTurn = myTurn;
        this.parent = parent;
        this.state = state;
        this.totalScore = 0;
        this.terminalState = terminalState;
    }

    public double getAvgScore() {
        if (timesVisited > 0)
            return (double) totalScore / (double) timesVisited;
        else
            return 0;
    }

    @Override
    public int compareTo(MC_Node node) {

        if (this.getAvgScore() == node.getAvgScore())
            return 0;
        else if (this.getAvgScore() < node.getAvgScore())
            return 1;
        else
            return -1;
    }
}