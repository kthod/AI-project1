package client;

import java.io.StringReader;
import java.util.*;

import client.Move;


import java.lang.Math;


public class World
{
	private String[][] board = null;
	private int rows = 7;
	private int columns = 5;
	private int myColor = 0;
	private ArrayList<String> availableMoves = null;
	private int rookBlocks = 3;		// rook can move towards <rookBlocks> blocks in any vertical or horizontal direction
	private int nTurns = 0;
	private int nBranches = 0;
	private int noPrize = 9;
	private int totalScore;
	private static final int limit=9;
	private  MC_Node currNode;
	//private int Iwon=0;
	//private int C=8;
	public int depth=80;

	public World()
	{
		board = new String[rows][columns];
		
		/* represent the board
		
		BP|BR|BK|BR|BP
		BP|BP|BP|BP|BP
		--|--|--|--|--
		P |P |P |P |P 
		--|--|--|--|--
		WP|WP|WP|WP|WP
		WP|WR|WK|WR|WP
		*/
		
		// initialization of the board
		for(int i=0; i<rows; i++)
			for(int j=0; j<columns; j++)
				board[i][j] = " ";
		
		// setting the black player's chess parts
		
		// black pawns
		for(int j=0; j<columns; j++)
			board[1][j] = "BP";
		
		board[0][0] = "BP";
		board[0][columns-1] = "BP";
		
		// black rooks
		board[0][1] = "BR";
		board[0][columns-2] = "BR";
		
		// black king
		board[0][columns/2] = "BK";
		
		// setting the white player's chess parts
		
		// white pawns
		for(int j=0; j<columns; j++)
			board[rows-2][j] = "WP";
		
		board[rows-1][0] = "WP";
		board[rows-1][columns-1] = "WP";
		
		// white rooks
		board[rows-1][1] = "WR";
		board[rows-1][columns-2] = "WR";
		
		// white king
		board[rows-1][columns/2] = "WK";
		
		// setting the prizes
		for(int j=0; j<columns; j++)
			board[rows/2][j] = "P";
		//board[3][1]= "BP";
		//board[4][2] = "WK";
		availableMoves = new ArrayList<String>();

		currNode = new MC_Node(null,board,null,true,false);

	}
	
	public void setMyColor(int myColor)
	{
		this.myColor = myColor;
	}
	
	public String selectAction(String algorithm,int score)
	{
		totalScore=score;
		//this.C=C;
		//this.depth=depth;
		availableMoves = new ArrayList<String>();

		if(myColor == 0)		// I am the white player
			this.whiteMoves(board);
		else					// I am the black player
			this.blackMoves(board);
		
		// keeping track of the branch factor
		nTurns++;
		nBranches += availableMoves.size();
		//if(myColor==0)
		if (algorithm.equals("MCTS")) {
			currNode = new MC_Node(null, board, null, true,false);
			return this.MonteCarloTreeSearch();
		}else if (algorithm.equals("minimax"))
			return this.AlphaBetaSearch();
		else {
			System.out.println("PLAYING RANDOM");
			return this.selectRandomAction();
		}
	}

	private void whiteMoves(String[][] board)
	{
		String firstLetter = "";
		String secondLetter = "";
		String move = "";

		for(int i=0; i<rows; i++)
		{
			for(int j=0; j<columns; j++)
			{
				firstLetter = Character.toString(board[i][j].charAt(0));

				// if it there is not a white chess part in this position then keep on searching
				if(firstLetter.equals("B") || firstLetter.equals(" ") || firstLetter.equals("P"))
					continue;

				// check the kind of the white chess part
				secondLetter = Character.toString(board[i][j].charAt(1));

				if(secondLetter.equals("P"))	// it is a pawn
				{

					// check if it can move one vertical position ahead
					firstLetter = Character.toString(board[i-1][j].charAt(0));

					if(firstLetter.equals(" ") || firstLetter.equals("P"))
					{
						move = Integer.toString(i) + Integer.toString(j) +
								Integer.toString(i-1) + Integer.toString(j);

						availableMoves.add(move);
					}

					// check if it can move crosswise to the left
					if(j!=0 && i!=0)
					{
						firstLetter = Character.toString(board[i-1][j-1].charAt(0));
						if(!(firstLetter.equals("W") || firstLetter.equals(" ") || firstLetter.equals("P"))) {
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i-1) + Integer.toString(j-1);

							availableMoves.add(move);
						}
					}

					// check if it can move crosswise to the right
					if(j!=columns-1 && i!=0)
					{
						firstLetter = Character.toString(board[i-1][j+1].charAt(0));
						if(!(firstLetter.equals("W") || firstLetter.equals(" ") || firstLetter.equals("P"))) {

							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i-1) + Integer.toString(j+1);
							availableMoves.add(move);
						}
					}
				}
				else if(secondLetter.equals("R"))	// it is a rook
				{
					// check if it can move upwards
					for(int k=0; k<rookBlocks; k++)
					{
						if((i-(k+1)) < 0)
							break;

						firstLetter = Character.toString(board[i-(k+1)][j].charAt(0));

						if(firstLetter.equals("W"))
							break;

						move = Integer.toString(i) + Integer.toString(j) +
								Integer.toString(i-(k+1)) + Integer.toString(j);

						availableMoves.add(move);

						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("B") || firstLetter.equals("P"))
							break;
					}

					// check if it can move downwards
					for(int k=0; k<rookBlocks; k++)
					{
						if((i+(k+1)) == rows)
							break;

						firstLetter = Character.toString(board[i+(k+1)][j].charAt(0));

						if(firstLetter.equals("W"))
							break;

						move = Integer.toString(i) + Integer.toString(j) +
								Integer.toString(i+(k+1)) + Integer.toString(j);

						availableMoves.add(move);

						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("B") || firstLetter.equals("P"))
							break;
					}

					// check if it can move on the left
					for(int k=0; k<rookBlocks; k++)
					{
						if((j-(k+1)) < 0)
							break;

						firstLetter = Character.toString(board[i][j-(k+1)].charAt(0));

						if(firstLetter.equals("W"))
							break;

						move = Integer.toString(i) + Integer.toString(j) +
								Integer.toString(i) + Integer.toString(j-(k+1));

						availableMoves.add(move);

						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("B") || firstLetter.equals("P"))
							break;
					}

					// check of it can move on the right
					for(int k=0; k<rookBlocks; k++)
					{
						if((j+(k+1)) == columns)
							break;

						firstLetter = Character.toString(board[i][j+(k+1)].charAt(0));

						if(firstLetter.equals("W"))
							break;

						move = Integer.toString(i) + Integer.toString(j) +
								Integer.toString(i) + Integer.toString(j+(k+1));

						availableMoves.add(move);

						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("B") || firstLetter.equals("P"))
							break;
					}
				}
				else // it is the king
				{
					// check if it can move upwards
					if((i-1) >= 0)
					{
						firstLetter = Character.toString(board[i-1][j].charAt(0));

						if(!firstLetter.equals("W"))
						{
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i-1) + Integer.toString(j);

							availableMoves.add(move);
						}
					}

					// check if it can move downwards
					if((i+1) < rows)
					{
						firstLetter = Character.toString(board[i+1][j].charAt(0));

						if(!firstLetter.equals("W"))
						{
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i+1) + Integer.toString(j);

							availableMoves.add(move);
						}
					}

					// check if it can move on the left
					if((j-1) >= 0)
					{
						firstLetter = Character.toString(board[i][j-1].charAt(0));

						if(!firstLetter.equals("W"))
						{
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i) + Integer.toString(j-1);

							availableMoves.add(move);
						}
					}

					// check if it can move on the right
					if((j+1) < columns)
					{
						firstLetter = Character.toString(board[i][j+1].charAt(0));

						if(!firstLetter.equals("W"))
						{
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i) + Integer.toString(j+1);

							availableMoves.add(move);
						}
					}
				}
			}
		}
	}

	private void blackMoves(String[][] board)
	{
		String firstLetter = "";
		String secondLetter = "";
		String move = "";

		for(int i=0; i<rows; i++)
		{
			for(int j=0; j<columns; j++)
			{
				firstLetter = Character.toString(board[i][j].charAt(0));

				// if it there is not a black chess part in this position then keep on searching
				if(firstLetter.equals("W") || firstLetter.equals(" ") || firstLetter.equals("P"))
					continue;

				// check the kind of the white chess part
				secondLetter = Character.toString(board[i][j].charAt(1));

				if(secondLetter.equals("P"))	// it is a pawn
				{

					// check if it can move one vertical position ahead
					firstLetter = Character.toString(board[i+1][j].charAt(0));

					if(firstLetter.equals(" ") || firstLetter.equals("P"))
					{
						move = Integer.toString(i) + Integer.toString(j) +
								Integer.toString(i+1) + Integer.toString(j);

						availableMoves.add(move);
					}

					// check if it can move crosswise to the left
					if(j!=0 && i!=rows-1)
					{
						firstLetter = Character.toString(board[i+1][j-1].charAt(0));

						if(!(firstLetter.equals("B") || firstLetter.equals(" ") || firstLetter.equals("P"))) {
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i+1) + Integer.toString(j-1);

							availableMoves.add(move);
						}
					}

					// check if it can move crosswise to the right
					if(j!=columns-1 && i!=rows-1)
					{
						firstLetter = Character.toString(board[i+1][j+1].charAt(0));

						if(!(firstLetter.equals("B") || firstLetter.equals(" ") || firstLetter.equals("P"))) {
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i+1) + Integer.toString(j+1);

							availableMoves.add(move);
						}



					}
				}
				else if(secondLetter.equals("R"))	// it is a rook
				{
					// check if it can move upwards
					for(int k=0; k<rookBlocks; k++)
					{
						if((i-(k+1)) < 0)
							break;

						firstLetter = Character.toString(board[i-(k+1)][j].charAt(0));

						if(firstLetter.equals("B"))
							break;

						move = Integer.toString(i) + Integer.toString(j) +
								Integer.toString(i-(k+1)) + Integer.toString(j);

						availableMoves.add(move);

						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("W") || firstLetter.equals("P"))
							break;
					}

					// check if it can move downwards
					for(int k=0; k<rookBlocks; k++)
					{
						if((i+(k+1)) == rows)
							break;

						firstLetter = Character.toString(board[i+(k+1)][j].charAt(0));

						if(firstLetter.equals("B"))
							break;

						move = Integer.toString(i) + Integer.toString(j) +
								Integer.toString(i+(k+1)) + Integer.toString(j);

						availableMoves.add(move);

						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("W") || firstLetter.equals("P"))
							break;
					}

					// check if it can move on the left
					for(int k=0; k<rookBlocks; k++)
					{
						if((j-(k+1)) < 0)
							break;

						firstLetter = Character.toString(board[i][j-(k+1)].charAt(0));

						if(firstLetter.equals("B"))
							break;

						move = Integer.toString(i) + Integer.toString(j) +
								Integer.toString(i) + Integer.toString(j-(k+1));

						availableMoves.add(move);

						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("W") || firstLetter.equals("P"))
							break;
					}

					// check of it can move on the right
					for(int k=0; k<rookBlocks; k++)
					{
						if((j+(k+1)) == columns)
							break;

						firstLetter = Character.toString(board[i][j+(k+1)].charAt(0));

						if(firstLetter.equals("B"))
							break;

						move = Integer.toString(i) + Integer.toString(j) +
								Integer.toString(i) + Integer.toString(j+(k+1));

						availableMoves.add(move);

						// prevent detouring a chesspart to attack the other
						if(firstLetter.equals("W") || firstLetter.equals("P"))
							break;
					}
				}
				else // it is the king
				{
					// check if it can move upwards
					if((i-1) >= 0)
					{
						firstLetter = Character.toString(board[i-1][j].charAt(0));

						if(!firstLetter.equals("B"))
						{
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i-1) + Integer.toString(j);

							availableMoves.add(move);
						}
					}

					// check if it can move downwards
					if((i+1) < rows)
					{
						firstLetter = Character.toString(board[i+1][j].charAt(0));

						if(!firstLetter.equals("B"))
						{
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i+1) + Integer.toString(j);

							availableMoves.add(move);
						}
					}

					// check if it can move on the left
					if((j-1) >= 0)
					{
						firstLetter = Character.toString(board[i][j-1].charAt(0));

						if(!firstLetter.equals("B"))
						{
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i) + Integer.toString(j-1);

							availableMoves.add(move);
						}
					}

					// check if it can move on the right
					if((j+1) < columns)
					{
						firstLetter = Character.toString(board[i][j+1].charAt(0));

						if(!firstLetter.equals("B"))
						{
							move = Integer.toString(i) + Integer.toString(j) +
									Integer.toString(i) + Integer.toString(j+1);

							availableMoves.add(move);
						}
					}
				}
			}
		}
	}

	
	private String selectRandomAction()
	{		
		Random ran = new Random();
		int x = ran.nextInt(availableMoves.size());
		
		return availableMoves.get(x);
	}
	
	public double getAvgBFactor()
	{
		return nBranches / (double) nTurns;
	}

	public void makeMove(int x1, int y1, int x2, int y2, int prizeX, int prizeY)
	{
		String chesspart = Character.toString(board[x1][y1].charAt(1));
		
		boolean pawnLastRow = false;
		
		// check if it is a move that has made a move to the last line
		if(chesspart.equals("P"))
			if( (x1==rows-2 && x2==rows-1) || (x1==1 && x2==0) )
			{
				board[x2][y2] = " ";	// in a case an opponent's chess part has just been captured
				board[x1][y1] = " ";
				pawnLastRow = true;
			}
		
		// otherwise
		if(!pawnLastRow)
		{
			board[x2][y2] = board[x1][y1];
			board[x1][y1] = " ";
		}
		
		// check if a prize has been added in the game
		if(prizeX != noPrize)
			board[prizeX][prizeY] = "P";

		//updateCurrNode(x1,y1,x2,y2);
	}
	//===================================================================
	//======================    UTIL    =================================
	//===================================================================

	//function to change the  state of a board by applying a given move
	//it also checks if it resulted state is terminal
	private boolean makeMoveOnTempBoard(String[][]tempBoard,String move)
	{
		int x1 = Integer.parseInt(Character.toString(move.charAt(0)));
		int y1 = Integer.parseInt(Character.toString(move.charAt(1)));
		int x2 = Integer.parseInt(Character.toString(move.charAt(2)));
		int y2 = Integer.parseInt(Character.toString(move.charAt(3)));

		boolean terminalState=false;

		String chesspart = Character.toString(tempBoard[x1][y1].charAt(1));
		
		boolean pawnLastRow = false;
		if((tempBoard[x2][y2].equals("WK")&&myColor==1) || (tempBoard[x2][y2].equals("BK")&&myColor==0) ){
			terminalState = true;
			//Iwon=1;
		}else if((tempBoard[x2][y2].equals("WK")&&myColor==0) || (tempBoard[x2][y2].equals("BK")&&myColor==1)) {
			terminalState = true;
			//Iwon = -1;
		}
		// check if it is a move that has made a move to the last line
		if(chesspart.equals("P"))
			if( (x1==rows-2 && x2==rows-1) || (x1==1 && x2==0) )
			{
				tempBoard[x2][y2] = " ";	// in a case an opponent's chess part has just been captured
				tempBoard[x1][y1] = " ";
				pawnLastRow = true;
			}

		// otherwise
		if(!pawnLastRow)
		{
			tempBoard[x2][y2] = tempBoard[x1][y1];
			tempBoard[x1][y1] = " ";
		}
		
		return terminalState;
	}

	//find all the available moves for the player who is about to play
	private void findAvailableMoves(String[][] state,boolean myTurn){

		availableMoves = new ArrayList<String>();
		if (myTurn) {
			if (myColor == 0)        // I am the white player
				this.whiteMoves(state);
			else                    // I am the black player
				this.blackMoves(state);
		}else{
			if (myColor == 0)        // I am the white player
				this.blackMoves(state);
			else                    // I am the black player
				this.whiteMoves(state);
		}

	}
	/*
	Copy the board to the new board and return the number of pieces
	 */
	private int copyBoard(String[][] board,String [][] newBoard){
		int numOfChessmen=0;

		for (int i=0; i < 7; i++){
			for (int j=0; j< 5; j++){
				newBoard[i][j] = board[i][j];
				if(board[i][j].equals("WP")){

					numOfChessmen++;
				}else if(board[i][j].equals("WR")){

					numOfChessmen++;
				}else if(board[i][j].equals("WK")){

					numOfChessmen++;
				}else if(board[i][j].equals("BP")){

					numOfChessmen++;
				}else if(board[i][j].equals("BR")){

					numOfChessmen++;
				}else if(board[i][j].equals("BK")){

					numOfChessmen++;
				}
			}
		}

		return numOfChessmen;
	}

//==================================================================================
//======================== ALPHABETA SEARCH METHODS ================================
//==================================================================================

	private String AlphaBetaSearch(){
		ArrayList<Move> tempAvailableMoves = sortvAvailableMoves(board);
		int v = Integer.MIN_VALUE;
		int index=0;
		int a=Integer.MIN_VALUE;
		int b=Integer.MAX_VALUE;

		for (int i = 0; i <tempAvailableMoves.size();i++ ){
			//start by being the maximizer
			int retval=minValue(board, tempAvailableMoves.get(i), a, b,0);
			if (v < retval ){
				v = retval;
				index=i;
			}	
			if(v >= b) {
				//System.out.println("ab cut");
				break;
			}

			a=Math.max(a,v);
		} 

		return tempAvailableMoves.get(index).getMove();
	}

	private int maxValue(String[][] State, Move move,int a, int b, int depth){
		depth++;

		totalScore=move.getScore();



		String [][] newState = new String[rows][columns];
		int numOfChessmen = copyBoard(State,newState);


		if (terminalState(newState,move.getMove(),numOfChessmen) || depth>=limit) return move.getScore();

		 makeMoveOnTempBoard(newState, move.getMove());
		findAvailableMoves(newState,true);
		ArrayList<Move> tempAvailableMoves = sortvAvailableMoves(newState);

		int v = Integer.MIN_VALUE;
		for (int i = 0; i <tempAvailableMoves.size();i++ ){

			v= Math.max(v, minValue(newState, tempAvailableMoves.get(i), a, b, depth) );

			if(v >= b) {
				totalScore=move.getScore();
				return v;
			}

			a=Math.max(a,v);
		}
		totalScore=move.getScore();
		return v;
	}

	private int minValue(String[][] State, Move move,int a, int b,int depth){
		depth++;

		totalScore=move.getScore();


		String [][] newState = new String[rows][columns];
		int numOfChessmen = copyBoard(State,newState);


		if (terminalState(newState,move.getMove(),numOfChessmen) || depth>=limit) return move.getScore();

		makeMoveOnTempBoard(newState, move.getMove());
		findAvailableMoves(newState,false);
		ArrayList<Move> tempAvailableMoves = sortvAvailableMoves(newState);

		int v = Integer.MAX_VALUE;
		for (int i = tempAvailableMoves.size()-1; i >= 0;i-- ){

			v= Math.min(v, maxValue(newState, tempAvailableMoves.get(i), a, b, depth) );

			if(v <= a) {
				totalScore=move.getScore();
				return v;
			}

			b=Math.min(b,v);
		}
		totalScore=move.getScore();
		return v;
	}
	           



	/*
function to evalute each move
it gets as arguments the board before the move and the the itself
and returns the score after the move is done
 */
	private int evaluateMove(String [][]tempBoard, String move)
	{
		int x1 = Integer.parseInt(Character.toString(move.charAt(0)));
		int y1 = Integer.parseInt(Character.toString(move.charAt(1)));
		int x2 = Integer.parseInt(Character.toString(move.charAt(2)));
		int y2 = Integer.parseInt(Character.toString(move.charAt(3)));

		int score=0;
		String chesspart = Character.toString(tempBoard[x1][y1].charAt(1));
		String color = Character.toString(tempBoard[x1][y1].charAt(0));
		int player;

		if (color.equals("W"))
			player=0;
		else
			player=1;

		boolean pawnLastRow = false;

		// check if it is a pawn heading to the last line and incrase by 1 the score
		if(chesspart.equals("P"))
			if( (x1==rows-2 && x2==rows-1) || (x1==1 && x2==0) )
			{

				if(myColor==player)
					score++;
				else
					score--;

			}

		// otherwise check what king of piece is about to be eaten and increase the score accordingly
		if(!pawnLastRow)
		{
			if(myColor==0){
				if(tempBoard[x2][y2].equals("BP")){
					score+=1;

				}else if(tempBoard[x2][y2].equals("BR")){
					score+=3;

				}else if(tempBoard[x2][y2].equals("BK")){
					score+=8;


				}else if(tempBoard[x2][y2].equals("WP")){
					score+=-1;

				}else if(tempBoard[x2][y2].equals("WR")){
					score+=-3;

				}else if(tempBoard[x2][y2].equals("WK")){
					score+=-8;


				}
			}
			else{
				if(tempBoard[x2][y2].equals("WP")){
					score+=1;

				}else if(tempBoard[x2][y2].equals("WR")){
					score+=3;

				}else if(tempBoard[x2][y2].equals("WK")){
					score+=8;


				}else if(tempBoard[x2][y2].equals("BP")){
					score+=-1;

				}else if(tempBoard[x2][y2].equals("BR")){
					score+=-3;

				}else if(tempBoard[x2][y2].equals("BK")){
					score+=-8;


				}
			}

			//check if a price is about to get a price
			if(tempBoard[x2][y2].equals("P")){
				if( player==myColor)
					score+=1;
				else
					score+=-1;

			}




		}

		return score;

	}
	//check if the following move leads to a terminal state
	private boolean terminalState(String [][]tempBoard, String move,int numOfchessmen){
		int x1 = Integer.parseInt(Character.toString(move.charAt(0)));
		int y1 = Integer.parseInt(Character.toString(move.charAt(1)));
		int x2 = Integer.parseInt(Character.toString(move.charAt(2)));
		int y2 = Integer.parseInt(Character.toString(move.charAt(3)));
		boolean terminalState = false;
		if((tempBoard[x2][y2].equals("WK")&&myColor==1) || (tempBoard[x2][y2].equals("BK")&&myColor==0) ){
			terminalState = true;
		}else if((tempBoard[x2][y2].equals("WK")&&myColor==0) || (tempBoard[x2][y2].equals("BK")&&myColor==1)) {
			terminalState = true;
		}else if(numOfchessmen==2)
		{
			terminalState = true;
		}
		return  terminalState;
	}

	/*
	method to reate a new Arraylist with the move and sot it with its score
	 */
	private ArrayList<Move> sortvAvailableMoves(String[][] state){
		String move;

		ArrayList<Move> sortedAvailableMoves = new ArrayList<Move>();
		for (int i=0; i< availableMoves.size();i++) {
			move= availableMoves.get(i);


			int score = evaluateMove(state, move);
			Move m = new Move(move, totalScore+score);

			sortedAvailableMoves.add(m);
		}
		Collections.sort(sortedAvailableMoves);

		return sortedAvailableMoves;
	}

	//========================================================================
	//=======================  MONTE CARLO TREE SEARCH =======================
	//========================================================================


	public String MonteCarloTreeSearch(){

		long Start = System.currentTimeMillis();
		long End = Start + 3998;
		int j=0;
		while(System.currentTimeMillis() < End) {

			MC_Node node = select();
			MC_Node Child = expand(node);

			int score = simulate(Child);

			backPropagate(score, Child);
		}
		MC_Node selectedNode = Collections.max(
				currNode.children,
				Comparator.comparing(c -> c.getAvgScore()));
		currNode = selectedNode;
		return selectedNode.move;

	}

	public MC_Node select(){
		MC_Node node = currNode;
		while (node.children.size() != 0) {
			node = findBestUCTMove(node);

		}
		return node;
	}

	private MC_Node findBestUCTMove(MC_Node m){
		int parentVisits = m.timesVisited;
				return Collections.max(
				m.children,
				Comparator.comparing(c -> UCT(c.getAvgScore(),parentVisits,c.timesVisited)));

	}
	private double UCT(double Vi, int N, int n){
		double C = 12;

		if(n!=0)
			return Vi +C*Math.sqrt(Math.log(N)/n);
		else
			return Double.MAX_VALUE;
	}


	private MC_Node expand(MC_Node node){
		findAvailableMoves(node.state, node.myTurn);
		for (int i=0; i < availableMoves.size();i++){
			String[][] newState = new String[rows][columns];
			int numOfChessmen=copyBoard(node.state, newState);
			boolean terminalState=makeMoveOnTempBoard(newState,availableMoves.get(i));

			if(!node.terminalState && numOfChessmen>2) {
				MC_Node child = new MC_Node(availableMoves.get(i), newState, node, !node.myTurn,terminalState);
				node.children.add(child);
			}
		}
		if(node.children.size()!=0)
			return node.children.get(0);
		else
			return node;
	}

	private int simulate(MC_Node node) {
		int depth=0;
		int score=0;
		while(true){
			findAvailableMoves(node.state, node.myTurn);



			String[][] newState = new String[rows][columns];
			int numOfChessmen=copyBoard(node.state, newState);

			if(((node.terminalState||numOfChessmen<=2||availableMoves.size()==0) && !node.equals(currNode)) || depth >=this.depth){
				score=evaluationMove_MC(node.parent.state, node.move );
				break;
			}

			String move = selectRandomAction();
			boolean terminalState=makeMoveOnTempBoard(newState, move);


			MC_Node child = new MC_Node(move, newState,node, !node.myTurn,terminalState);
			node = child;
			depth++;

		}

		return score;

	}

	private void backPropagate(int score,MC_Node node){
		do{
			if(!node.myTurn)
				node.totalScore+=score;
			else if(node.myTurn )
				node.totalScore-=score;

			node.timesVisited++;
			node=node.parent;

		}while(node!=null);
	}



	public int evaluationMove_MC(String [][] state,String move){
		int score=0;
		int x1 = Integer.parseInt(Character.toString(move.charAt(0)));
		int y1 = Integer.parseInt(Character.toString(move.charAt(1)));
		int x2 = Integer.parseInt(Character.toString(move.charAt(2)));
		int y2 = Integer.parseInt(Character.toString(move.charAt(3)));

		String chesspart = Character.toString(state[x1][y1].charAt(1));
		String color = Character.toString(state[x1][y1].charAt(0));

		int player;
		if (color.equals("W"))
			player=0;
		else
			player=1;



		// check if it is a move that has made a move to the last line
		if(chesspart.equals("P"))
			if( (x1==rows-2 && x2==rows-1) || (x1==1 && x2==0) )
			{

				if(myColor==player)
					score++;
				else
					score--;

			}

		if(state[x2][y2].equals("P")){
			if( player==myColor)
				score++;
			else
				score--;

		}
		String[][] newState=new String[rows][columns];
		copyBoard(state,newState);
		makeMoveOnTempBoard(newState,move);
		if(myColor==0){
			for (int i=0; i < 7; i++){
				for (int j=0; j< 5; j++){

					if(newState[i][j].equals("WP")){
						score++;
					}else if(newState[i][j].equals("WR")){
						score+=3;
					}else if(newState[i][j].equals("WK")){
						score+=8;
					}else if(newState[i][j].equals("BP")){
						score--;
					}else if(newState[i][j].equals("BR")){
						score-=3;
					}else if(newState[i][j].equals("BK")){
						score-=8;
					}
				}
			}


		}else{
			for (int i=0; i < 7; i++){
				for (int j=0; j< 5; j++){
					if(newState[i][j].equals("BP")){
						score++;
					}else if(newState[i][j].equals("BR")){
						score+=3;
					}else if(newState[i][j].equals("BK")){
						score+=8;
					}else if(newState[i][j].equals("WP")){
						score--;
					}else if(newState[i][j].equals("WR")){
						score-=3;
					}else if(newState[i][j].equals("WK")) {
						score -= 8;
					}
				}
			}



		}



	return score;

	}




}
