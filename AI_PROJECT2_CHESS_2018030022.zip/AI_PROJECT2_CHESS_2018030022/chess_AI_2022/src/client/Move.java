package client;

import java.lang.Comparable;


public class Move implements Comparable<Move>
{
    private String move;
    private int score;

    public Move(String move, int score){
        this.move = move;
        this.score = score;
    }

    public String getMove(){
        return this.move;
    }

    public int getScore(){
        return this.score;
    }

    public int compareTo(Move m) {
	
		if(this.score==m.getScore())    
        return 0;    
        else if(this.score<m.getScore())    
        return 1;    
        else    
        return -1;    
		
	}	

}