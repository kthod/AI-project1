package server;

import javax.swing.ImageIcon;


public class King extends ChessPart
{	
	public King(int player, ImageIcon icon)
	{
		super(player, icon);
		this.pointsWorth = 8;
	}
	
}
